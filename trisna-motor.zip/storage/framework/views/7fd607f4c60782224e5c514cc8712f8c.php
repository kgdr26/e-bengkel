<?php $__env->startSection('content'); ?>

<div class="container">
    <!-- row -->
    <div class="row mb-8">
        <div class="col-md-12">
            <div class="d-md-flex justify-content-between align-items-center">
                <!-- pageheader -->
                <div>
                    <h2>List Booking</h2>
                    <!-- breacrumb -->
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="#" class="text-inherit">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">List Booking</li>
                        </ol>
                    </nav>
                </div>
                <!-- button -->
            </div>
        </div>
    </div>

    <div class="row ">
        <div class="col-xl-12 col-12 mb-5">
            <!-- card -->
            <div class="card h-100 card-lg">
                <!-- card body -->
                <div class="card-body p-3">
                    <!-- table -->
                    <div class="table-responsive ">
                        <table class="table table-centered table-hover mb-0 text-nowrap table-borderless table-with-checkbox" id="dataTable">
                            <thead class="bg-light">
                                <tr>
                                    <th>No</th>
                                    <th>Name Customer</th>
                                    <th>No Tlp</th>
                                    <th>Nopol</th>
                                    <th>Merk Kendaraan</th>
                                    <th>Keperluan</th>
                                    <th>Date Booking</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e($value->no_tlp); ?></td>
                                        <td><?php echo e($value->nopol); ?></td>
                                        <td><?php echo e($value->merk_kendaraan); ?></td>
                                        <td><?php echo e($value->kep_name); ?></td>
                                        <td><?php echo e($value->date_booking); ?></td>
                                        <td>
                                            <?php if($value->status == 1): ?>
                                                <span class="badge bg-light-warning text-dark-warning">Booking</span>
                                            <?php elseif($value->status == 2): ?>
                                                <span class="badge bg-light-primary text-dark-primary">Confirmation</span>
                                            <?php elseif($value->status == 3): ?>
                                                <span class="badge bg-light-info text-dark-info">Processing</span>
                                            <?php elseif($value->status == 4): ?>
                                                <span class="badge bg-light-success text-dark-success">Finished</span>
                                            <?php else: ?>
                                                <span class="badge bg-light-warning text-dark-warning">Booking</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<script>
    $('#dataTable').DataTable();
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\e-bengkel\resources\views/Dashboard/listbooking.blade.php ENDPATH**/ ?>