<?php $__env->startSection('content'); ?>


<section class="container">
    
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\e-bengkel\resources\views/Dashboard/dasbor.blade.php ENDPATH**/ ?>